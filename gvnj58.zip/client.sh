#!/bin/sh

cd bin
java Client
cd ..
